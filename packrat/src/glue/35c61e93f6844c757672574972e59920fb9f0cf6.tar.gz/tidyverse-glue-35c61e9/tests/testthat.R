library(testthat)
library(glue)

test_check("glue")
