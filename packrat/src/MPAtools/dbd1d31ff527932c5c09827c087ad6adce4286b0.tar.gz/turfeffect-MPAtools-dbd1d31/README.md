# MPAtools
R package to simulate Marine Protected Areas, created by the [**TURFeffect**](http://turfeffect.github.io/) group at Bren School, UCSB. For more information, contact the developers at <jvillasenor@bren.ucsb.edu>

Please note that this project is released with a [Contributor Code of Conduct](CONDUCT.md). By participating in this project you agree to abide by its terms.
